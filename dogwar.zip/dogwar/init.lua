
local modname = minetest.get_current_modname()
assert(modname == "dogwar", "mod can't be renamed")
local path = minetest.get_modpath(modname) .. "/"

dogwar = {}

dofile(path.."tank.lua")
--dofile(path.."truck.lua")
dofile(path.."construction.lua")
